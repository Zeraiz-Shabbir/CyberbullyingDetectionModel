from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator

def evaluate_model(model, test_data):
    predictions = model.transform(test_data)
    evaluator = BinaryClassificationEvaluator(labelCol="binary_label", rawPredictionCol="rawPrediction")
    area_under_curve = evaluator.evaluate(predictions)
    print(f"Area Under ROC (Balanced): {area_under_curve}")
    evaluator_accuracy = MulticlassClassificationEvaluator(labelCol="binary_label", predictionCol="prediction", metricName="accuracy")
    accuracy = evaluator_accuracy.evaluate(predictions)
    print(f"Accuracy (Balanced): {accuracy}")
    evaluator_f1 = MulticlassClassificationEvaluator(labelCol="binary_label", predictionCol="prediction", metricName="f1")
    f1_score = evaluator_f1.evaluate(predictions)
    print(f"F1 Score (Balanced): {f1_score}")
