import load_data
import preprocess_data
import train_model
import evaluate_model

if __name__ == "__main__":
    file_path = "cyberbullying_tweets.csv"
    df = load_data.load_data(file_path)
    model = train_model.train_model(df)
    evaluate_model.evaluate_model(model, df)
