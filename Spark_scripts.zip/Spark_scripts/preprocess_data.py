from pyspark.ml.feature import Tokenizer, StopWordsRemover, StringIndexer, NGram, HashingTF, IDF
from pyspark.sql.functions import lower, udf
from pyspark.sql.types import FloatType
from textblob import TextBlob

def get_sentiment(tweet):
    analysis = TextBlob(tweet)
    return analysis.sentiment.polarity

def preprocess_data(df):
    df = df.withColumn("cleaned_tweet", lower(df["tweet_text"]))
    tokenizer = Tokenizer(inputCol="cleaned_tweet", outputCol="tokens")
    df = tokenizer.transform(df)
    remover = StopWordsRemover(inputCol="tokens", outputCol="filtered_tokens")
    df = remover.transform(df)
    indexer = StringIndexer(inputCol="cyberbullying_type", outputCol="label", handleInvalid="skip")
    df = indexer.fit(df).transform(df)
    udf_get_sentiment = udf(get_sentiment, FloatType())
    df = df.withColumn("sentiment_score", udf_get_sentiment("cleaned_tweet"))
    ngram = NGram(n=3, inputCol="filtered_tokens", outputCol="trigrams")
    df = ngram.transform(df)
    return df
