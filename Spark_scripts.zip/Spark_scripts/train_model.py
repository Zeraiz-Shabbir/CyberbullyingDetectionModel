import preprocess_data
from pyspark.ml.feature import HashingTF, IDF
from pyspark.ml.classification import NaiveBayes
from pyspark.ml import Pipeline

def train_model(df):
    hashingTF = HashingTF(inputCol="trigrams", outputCol="features", numFeatures=4096)
    idf = IDF(inputCol="features", outputCol="tf_idf_features")
    nb = NaiveBayes(featuresCol="tf_idf_features", labelCol="binary_label")
    pipeline = Pipeline(stages=[hashingTF, idf, nb])
    train_data, test_data = preprocess_data.preprocess_data(df).randomSplit([0.8, 0.2], seed=42)
    model = pipeline.fit(train_data)
    return model
